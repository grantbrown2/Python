# 1. TASK: print "Hello World"
print("Hello World!")
# 2. print "Hello Noelle!" with the name in a variable
name = "Grant!"
print("Hello", name)	# with a comma
print("Hello " + name)	# with a +
# 3. print "Hello 42!" with the number in a variable
name = 2
print("Hello", name,)	# with a comma
print("Hello " + str(name))	# with a +	-- this one should give us an error! However it doesn't because I have changed name as an int, to a string. Due to the fact you cannot add a string and a number.
# 4. print "I love to eat sushi and pizza." with the foods in variables
fave_food1 = "buffalo wings"
fave_food2 = "pizza"
print("I love to eat {} and {}".format(fave_food1, fave_food2)) # with .format()
print(f"I love to eat {fave_food1} and {fave_food2}") # with an f string
print("I love to eat", fave_food1, "and", fave_food2) # another way of doing it